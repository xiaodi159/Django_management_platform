from django.shortcuts import render,HttpResponse

def test_view(request):
    print("请耐心等待！")
    return render(request,"button.html")
